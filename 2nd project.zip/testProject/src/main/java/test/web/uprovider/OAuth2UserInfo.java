package test.web.uprovider;

public interface OAuth2UserInfo {

	public String getProviderid();
	public String getEmail();
	public String getName();
	
}
